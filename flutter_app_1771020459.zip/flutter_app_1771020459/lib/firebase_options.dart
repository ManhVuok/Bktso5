// File: lib/firebase_options.dart
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        return linux;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:web:abc123def456ghi789jkl', // Thay bằng App ID Web nếu có
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    authDomain: 'restaurant-1771020459.firebaseapp.com',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
    measurementId: 'G-XXXXXXXXXX', // Thay bằng Measurement ID nếu có
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:android:babbc5593c8f72ea75a247',
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:ios:abc123def456ghi789jkl', // Thay bằng App ID iOS nếu có
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
    iosBundleId: 'com.example.1771020459',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:ios:abc123def456ghi789jkl', // Thay bằng App ID macOS nếu có
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
    iosBundleId: 'com.example.1771020459',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:web:abc123def456ghi789jkl', // Thay bằng App ID Windows nếu có
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    authDomain: 'restaurant-1771020459.firebaseapp.com',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
    measurementId: 'G-XXXXXXXXXX', // Thay bằng Measurement ID nếu có
  );

  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: 'AIzaSyCA73NWa_oy70qteZaTwqgojS5TCyawz5U',
    appId: '1:636557412422:web:abc123def456ghi789jkl', // Thay bằng App ID Linux nếu có
    messagingSenderId: '636557412422',
    projectId: 'restaurant-1771020459',
    authDomain: 'restaurant-1771020459.firebaseapp.com',
    storageBucket: 'restaurant-1771020459.firebasestorage.app',
    measurementId: 'G-XXXXXXXXXX', // Thay bằng Measurement ID nếu có
  );
}