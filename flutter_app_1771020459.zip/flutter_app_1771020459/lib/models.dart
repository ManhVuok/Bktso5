import 'package:cloud_firestore/cloud_firestore.dart';

class MenuItem {
  String id, name, description, category, imageUrl;
  double price, rating;
  List<String> ingredients;
  bool isVegetarian, isSpicy, isAvailable;
  int preparationTime;

  MenuItem({
    required this.id, required this.name, required this.description,
    required this.category, required this.price, required this.imageUrl,
    required this.ingredients, required this.isVegetarian, required this.isSpicy,
    required this.preparationTime, required this.isAvailable, required this.rating
  });

  factory MenuItem.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return MenuItem(
      id: doc.id,
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      category: data['category'] ?? 'Main Course',
      price: (data['price'] ?? 0).toDouble(),
      imageUrl: data['imageUrl'] ?? '',
      ingredients: List<String>.from(data['ingredients'] ?? []),
      isVegetarian: data['isVegetarian'] ?? false,
      isSpicy: data['isSpicy'] ?? false,
      preparationTime: data['preparationTime'] ?? 0,
      isAvailable: data['isAvailable'] ?? true,
      rating: (data['rating'] ?? 0).toDouble(),
    );
  }
}

class Customer {
  String id, email, fullName, phoneNumber, address;
  List<String> preferences;
  int loyaltyPoints;
  DateTime createdAt;
  bool isActive;

  Customer({
    required this.id, required this.email, required this.fullName,
    required this.phoneNumber, required this.address, required this.preferences,
    required this.loyaltyPoints, required this.createdAt, required this.isActive
  });

  factory Customer.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Customer(
      id: doc.id,
      email: data['email'] ?? '',
      fullName: data['fullName'] ?? '',
      phoneNumber: data['phoneNumber'] ?? '',
      address: data['address'] ?? '',
      preferences: List<String>.from(data['preferences'] ?? []),
      loyaltyPoints: data['loyaltyPoints'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      isActive: data['isActive'] ?? true,
    );
  }
}

class ReservationModel {
  String id, customerId, status, paymentStatus, specialRequests;
  DateTime reservationDate;
  int numberOfGuests;
  String? tableNumber;
  List<Map<String, dynamic>> orderItems;
  double subtotal, serviceCharge, discount, total;
  String? paymentMethod;
  DateTime createdAt, updatedAt;

  ReservationModel({
    required this.id, required this.customerId, required this.reservationDate,
    required this.numberOfGuests, required this.status, required this.paymentStatus,
    required this.specialRequests, this.tableNumber, required this.orderItems,
    required this.subtotal, required this.serviceCharge, required this.discount, required this.total,
    this.paymentMethod, required this.createdAt, required this.updatedAt,
  });

  factory ReservationModel.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return ReservationModel(
      id: doc.id,
      customerId: data['customerId'] ?? '',
      reservationDate: (data['reservationDate'] as Timestamp).toDate(),
      numberOfGuests: data['numberOfGuests'] ?? 1,
      status: data['status'] ?? 'pending',
      paymentStatus: data['paymentStatus'] ?? 'pending',
      specialRequests: data['specialRequests'] ?? '',
      tableNumber: data['tableNumber'],
      orderItems: List<Map<String, dynamic>>.from(data['orderItems'] ?? []),
      subtotal: (data['subtotal'] ?? 0).toDouble(),
      serviceCharge: (data['serviceCharge'] ?? 0).toDouble(),
      discount: (data['discount'] ?? 0).toDouble(),
      total: (data['total'] ?? 0).toDouble(),
      paymentMethod: data['paymentMethod'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }
}