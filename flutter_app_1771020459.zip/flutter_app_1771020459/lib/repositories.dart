import 'package:cloud_firestore/cloud_firestore.dart';
import 'models.dart';

class CustomerRepository {
  final _db = FirebaseFirestore.instance.collection('customers');

  Future<void> addCustomer(Customer customer) async {
    await _db.doc(customer.id).set({
      'email': customer.email,
      'fullName': customer.fullName,
      'phoneNumber': customer.phoneNumber,
      'address': customer.address,
      'preferences': customer.preferences,
      'loyaltyPoints': customer.loyaltyPoints,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': customer.isActive,
    });
  }

  Future<Customer?> getCustomerById(String id) async {
    final doc = await _db.doc(id).get();
    return doc.exists ? Customer.fromFirestore(doc) : null;
  }

  Future<List<Customer>> getAllCustomers() async {
    final snapshot = await _db.get();
    return snapshot.docs.map((doc) => Customer.fromFirestore(doc)).toList();
  }

  Future<void> updateCustomer(String id, Map<String, dynamic> data) async {
    await _db.doc(id).update(data);
  }

  Future<void> updateLoyaltyPoints(String id, int points) async {
    await _db.doc(id).update({'loyaltyPoints': points});
  }
}

class MenuItemRepository {
  final _db = FirebaseFirestore.instance.collection('menu_items');

  Future<void> addMenuItem(MenuItem item) async {
    await _db.doc(item.id).set({
      'name': item.name,
      'description': item.description,
      'category': item.category,
      'price': item.price,
      'imageUrl': item.imageUrl,
      'ingredients': item.ingredients,
      'isVegetarian': item.isVegetarian,
      'isSpicy': item.isSpicy,
      'preparationTime': item.preparationTime,
      'isAvailable': item.isAvailable,
      'rating': item.rating,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<MenuItem?> getMenuItemById(String id) async {
    final doc = await _db.doc(id).get();
    return doc.exists ? MenuItem.fromFirestore(doc) : null;
  }

  Future<List<MenuItem>> getAllMenuItems() async {
    final snapshot = await _db.get();
    return snapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList();
  }

  Future<List<MenuItem>> searchMenuItems(String query) async {
    final snapshot = await _db.get();
    return snapshot.docs
        .map((doc) => MenuItem.fromFirestore(doc))
        .where((item) =>
            item.name.toLowerCase().contains(query.toLowerCase()) ||
            item.description.toLowerCase().contains(query.toLowerCase()) ||
            item.ingredients.any((ing) => ing.toLowerCase().contains(query.toLowerCase())))
        .toList();
  }

  Future<List<MenuItem>> filterMenuItems({String? category, bool? isVegetarian, bool? isSpicy}) async {
    Query query = _db;
    if (category != null) query = query.where('category', isEqualTo: category);
    if (isVegetarian != null) query = query.where('isVegetarian', isEqualTo: isVegetarian);
    if (isSpicy != null) query = query.where('isSpicy', isEqualTo: isSpicy);
    final snapshot = await query.get();
    return snapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList();
  }

  Stream<List<MenuItem>> getAllMenuItemsStream() {
    return _db.snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList());
  }

  Stream<List<MenuItem>> searchMenuItemsStream(String query) {
    return _db
        .where('name', isGreaterThanOrEqualTo: query)
        .where('name', isLessThanOrEqualTo: query + '\uf8ff')
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList());
  }

  Stream<List<MenuItem>> filterMenuItemsStream({String? category, bool? isVegetarian, bool? isSpicy}) {
    Query query = _db;
    if (category != null) query = query.where('category', isEqualTo: category);
    if (isVegetarian != null) query = query.where('isVegetarian', isEqualTo: isVegetarian);
    if (isSpicy != null) query = query.where('isSpicy', isEqualTo: isSpicy);
    return query.snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList());
  }
}

class ReservationRepository {
  final _db = FirebaseFirestore.instance.collection('reservations');

  Future<String> createReservation(String customerId, DateTime reservationDate, int numberOfGuests, String specialRequests) async {
    final docRef = await _db.add({
      'customerId': customerId,
      'reservationDate': Timestamp.fromDate(reservationDate),
      'numberOfGuests': numberOfGuests,
      'specialRequests': specialRequests,
      'status': 'pending',
      'paymentStatus': 'pending',
      'tableNumber': null,
      'orderItems': [],
      'subtotal': 0.0,
      'serviceCharge': 0.0,
      'discount': 0.0,
      'total': 0.0,
      'paymentMethod': null,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return docRef.id;
  }

  Future<void> addItemToReservation(String reservationId, String itemId, int quantity) async {
    final itemRepo = MenuItemRepository();
    final item = await itemRepo.getMenuItemById(itemId);
    if (item == null || !item.isAvailable) throw Exception('Item not available');

    final ref = _db.doc(reservationId);
    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snapshot = await tx.get(ref);
      List<dynamic> items = List.from(snapshot.get('orderItems'));
      
      double price = item.price;
      double lineTotal = price * quantity;

      items.add({
        'itemId': item.id,
        'itemName': item.name,
        'quantity': quantity,
        'price': price,
        'subtotal': lineTotal
      });

      double subtotal = items.fold(0, (sum, i) => sum + i['subtotal']);
      double serviceCharge = subtotal * 0.10;
      double total = subtotal + serviceCharge;

      tx.update(ref, {
        'orderItems': items,
        'subtotal': subtotal,
        'serviceCharge': serviceCharge,
        'total': total,
        'updatedAt': FieldValue.serverTimestamp()
      });
    });
  }

  Future<void> confirmReservation(String reservationId, String tableNumber) async {
    await _db.doc(reservationId).update({
      'status': 'confirmed',
      'tableNumber': tableNumber,
      'updatedAt': FieldValue.serverTimestamp()
    });
  }

  Future<void> payReservation(String reservationId, String paymentMethod) async {
    final ref = _db.doc(reservationId);
    await FirebaseFirestore.instance.runTransaction((tx) async {
      final resSnap = await tx.get(ref);
      final customerId = resSnap.get('customerId');
      final total = resSnap.get('total') as double;
      
      final customerSnap = await tx.get(FirebaseFirestore.instance.collection('customers').doc(customerId));
      int points = customerSnap.get('loyaltyPoints') ?? 0;
      
      double maxDisc = total * 0.5;
      double potentialDisc = points * 1000.0;
      double actualDisc = (potentialDisc > maxDisc) ? maxDisc : potentialDisc;
      double finalTotal = total - actualDisc;
      int pointsUsed = (actualDisc / 1000).ceil();
      int pointsEarned = (finalTotal * 0.01).floor();
      
      tx.update(ref, {
        'status': 'completed',
        'paymentStatus': 'paid',
        'discount': actualDisc,
        'total': finalTotal,
        'paymentMethod': paymentMethod,
        'updatedAt': FieldValue.serverTimestamp()
      });
      
      tx.update(FirebaseFirestore.instance.collection('customers').doc(customerId), {
        'loyaltyPoints': (points - pointsUsed) + pointsEarned
      });
    });
  }

  Future<List<ReservationModel>> getReservationsByCustomer(String customerId) async {
    final snapshot = await _db.where('customerId', isEqualTo: customerId).get();
    return snapshot.docs.map((doc) => ReservationModel.fromFirestore(doc)).toList();
  }

  Future<List<ReservationModel>> getReservationsByDate(String date) async {
    // Assuming date is YYYY-MM-DD
    final start = DateTime.parse(date);
    final end = start.add(const Duration(days: 1));
    final snapshot = await _db
        .where('reservationDate', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('reservationDate', isLessThan: Timestamp.fromDate(end))
        .get();
    return snapshot.docs.map((doc) => ReservationModel.fromFirestore(doc)).toList();
  }

  Stream<List<ReservationModel>> getReservationsByCustomerStream(String customerId) {
    return _db
        .where('customerId', isEqualTo: customerId)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => ReservationModel.fromFirestore(doc)).toList());
  }

  Future<void> cancelReservation(String reservationId) async {
    await _db.doc(reservationId).update({
      'status': 'cancelled',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateReservation(String reservationId, Map<String, dynamic> data) async {
    data['updatedAt'] = FieldValue.serverTimestamp();
    await _db.doc(reservationId).update(data);
  }
}