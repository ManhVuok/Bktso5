import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthProvider extends ChangeNotifier {
  String? currentCustomerId;
  bool get isAuthenticated => currentCustomerId != null;

  Future<void> login(String email) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('customers')
        .where('email', isEqualTo: email)
        .limit(1)
        .get();
    
    if (snapshot.docs.isNotEmpty) {
      currentCustomerId = snapshot.docs.first.id;
      notifyListeners();
    } else {
      throw Exception("Email không tồn tại!");
    }
  }

  Future<void> register(String email, String name, String phone, String address, List<String> prefs) async {
    final docRef = await FirebaseFirestore.instance.collection('customers').add({
      'email': email,
      'fullName': name,
      'phoneNumber': phone,
      'address': address,
      'preferences': prefs,
      'loyaltyPoints': 0,
      'isActive': true,
      'createdAt': FieldValue.serverTimestamp()
    });
    currentCustomerId = docRef.id;
    notifyListeners();
  }
  
  void logout() {
    currentCustomerId = null;
    notifyListeners();
  }
}