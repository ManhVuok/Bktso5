import 'package:cloud_firestore/cloud_firestore.dart';

class SampleDataService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> addSampleData() async {
    await _addSampleMenuItems();
  }

  Future<void> _addSampleMenuItems() async {
    // Clear existing data
    final batch = _db.batch();
    final snapshot = await _db.collection('menu_items').get();
    for (var doc in snapshot.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();

    final menuItems = [
      {
        'name': 'Gỏi cuốn tôm thịt',
        'description': 'Gỏi cuốn tươi ngon với tôm và thịt heo',
        'category': 'Khai vị',
        'price': 45000.0,
        'imageUrl': 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop',
        'ingredients': ['Tôm', 'Thịt heo', 'Bún', 'Rau sống', 'Nước mắm'],
        'isVegetarian': false,
        'isSpicy': false,
        'isAvailable': true,
      },
      {
        'name': 'Phở bò',
        'description': 'Phở bò truyền thống Hà Nội',
        'category': 'Món chính',
        'price': 55000.0,
        'imageUrl': 'https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=400&h=300&fit=crop',
        'ingredients': ['Bò', 'Bánh phở', 'Nước dùng', 'Hành', 'Gừng'],
        'isVegetarian': false,
        'isSpicy': false,
        'isAvailable': true,
      },
      {
        'name': 'Cơm tấm sườn bì',
        'description': 'Cơm tấm với sườn nướng và bì',
        'category': 'Món chính',
        'price': 65000.0,
        'imageUrl': 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop',
        'ingredients': ['Cơm', 'Sườn heo', 'Bì', 'Trứng ốp la', 'Chả'],
        'isVegetarian': false,
        'isSpicy': false,
        'isAvailable': true,
      },
      {
        'name': 'Gỏi ngó sen tôm thịt',
        'description': 'Gỏi ngó sen tươi mát',
        'category': 'Khai vị',
        'price': 55000.0,
        'imageUrl': 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400&h=300&fit=crop',
        'ingredients': ['Ngó sen', 'Tôm', 'Thịt gà', 'Đậu phộng', 'Nước mắm'],
        'isVegetarian': false,
        'isSpicy': false,
        'isAvailable': true,
      },
      {
        'name': 'Bún riêu cua',
        'description': 'Bún riêu cua đồng',
        'category': 'Món chính',
        'price': 50000.0,
        'imageUrl': 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=300&fit=crop',
        'ingredients': ['Bún', 'Riêu cua', 'Tôm', 'Giá', 'Chanh'],
        'isVegetarian': false,
        'isSpicy': false,
        'isAvailable': true,
      },
    ];

    for (final item in menuItems) {
      await _db.collection('menu_items').add({
        ...item,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }
}